package org.jruby.internal.runtime.methods;

public enum Scoping { Full, Dummy, None }
