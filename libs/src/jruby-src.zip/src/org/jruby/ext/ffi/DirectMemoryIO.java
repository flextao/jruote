
package org.jruby.ext.ffi;

public interface DirectMemoryIO extends MemoryIO {
    long getAddress();
}
